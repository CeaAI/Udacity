DROP TABLE IF EXISTS country;

CREATE TABLE IF NOT EXISTS public.country
(
	countryName varchar NOT NULL,
	countrycode varchar (3) NOT NULL,
	continent varchar NOT NULL,
  CONSTRAINT country_pkey PRIMARY KEY (countryName)
);

DROP TABLE IF EXISTS city;

CREATE TABLE IF NOT EXISTS public.city (

    city varchar NOT NULL,
    country varchar NOT NULL,
    longitude decimal(26,6),
    latitude decimal(26,6),
	CONSTRAINT city_pkey PRIMARY KEY (city)
);


CREATE TABLE IF NOT EXISTS public.time (
	dt date not null,
	"day" integer,
	"month" integer,
	"year" integer,
	CONSTRAINT time_pkey PRIMARY KEY (dt)
);

DROP TABLE IF EXISTS landTemperatures;

CREATE TABLE IF NOT EXISTS public.landTemperatures (
	tempId integer IDENTITY(0,1),
	cityName varchar NOT NULL,
	countryName varchar NOT NULL,
	date date NOT NULL,
    averageMonthlyTemperature decimal(26,6) NOT NULL,
	CONSTRAINT landTemperatures_pkey PRIMARY KEY (tempId)
);


DROP TABLE IF EXISTS climateFactors;

CREATE TABLE IF NOT EXISTS public.climateFactors (
	factorId integer IDENTITY(0,1),
	totalEmissions decimal(26,6) not null,
    populationDensity decimal(26,6) not null,
    averageYearlyTemperature decimal(26,6) not null,
    "year" integer not null,
    countryName varchar not null,
	CONSTRAINT climaticFactors_pkey PRIMARY KEY (factorId)
);

DROP TABLE IF EXISTS stagingTempCity;

CREATE TABLE IF NOT EXISTS public.stagingTempCity (
	dt date,
	averageTemperature decimal(26,6),
	averageTemperatureUncertainty decimal(26,6),
    city varchar,
    country varchar,
    latitude varchar,
    longitude varchar
);

DROP TABLE IF EXISTS stagingTempCountry;

CREATE TABLE IF NOT EXISTS public.stagingTempCountry (
	dt date,
    country varchar,
	averageTemperature decimal(26,6),
	averageTemperatureUncertianty decimal(26,6)
);


DROP TABLE IF EXISTS stagingGHGEmissions;

CREATE TABLE IF NOT EXISTS public.stagingGHGEmissions (
	country varchar not null,
	code varchar,
    "year" integer,
	totalGHGEmissions decimal(26,6)
);

DROP TABLE IF EXISTS stagingPopulationDensity;

CREATE TABLE IF NOT EXISTS public.stagingPopulationDensity (
	country varchar,
	code varchar(3),
    year integer,
    populationDensity decimal(26,6)
);

DROP TABLE IF EXISTS stagingCountries;

CREATE TABLE IF NOT EXISTS public.stagingCountries (
	continent_name varchar,
	continent_code varchar(2),
    country_name  varchar,
    two_letter_country_code varchar(2),
    three_letter_country_code varchar(3),
    country_number decimal(26,6)
);
