from datetime import datetime, timedelta
import os
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.postgres_operator import PostgresOperator
from airflow.operators import (StageToRedshiftOperator, LoadFactOperator,
                                LoadDimensionOperator, DataQualityOperator)
from helpers import SqlQueries

# AWS_KEY = os.environ.get('AWS_KEY')
# AWS_SECRET = os.environ.get('AWS_SECRET')
'''\
## Land Tempererature Analysis Pipeline 

This dag is used to build a data pipeline for analysing the effect of green house gases emissions and population density on global land temperatures, , automating ETL processes from S3 into Redshift (data warehouse)

'''
default_args = {
    'owner': 'cea',
    'start_date': datetime.now()- timedelta(seconds=20),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'catchup': False,
    'email_on_retry': False
    
}

dag = DAG('climate_dag2',
          default_args=default_args,
          description='Load and transform data in Redshift with Airflow',
          schedule_interval="@yearly"
          )
dag.doc_md = __doc__

start_operator = DummyOperator(task_id='Begin_execution',  dag=dag)
start_operator.doc_md = '''\
    ### Start Operator
    Starts up the execution of the pipeline
    
    '''
stage_global_temp_by_city_to_redshift = StageToRedshiftOperator(
    task_id='Stage_global_temp_by_city',
    dag=dag,
    table="stagingTempCity",
    s3_key="Climate_Data/GlobalLandTempByCity",

)

stage_global_temp_by_country_to_redshift = StageToRedshiftOperator(
    task_id='Stage_global_temp_by_country',
    dag=dag,    
    table="stagingTempCountry",
    s3_key= "Climate_Data/GlobalLandTempByCountry"
)

stage_country_to_redshift = StageToRedshiftOperator(
    task_id='Stage_countries',
    dag=dag,    
    table="stagingCountries",
    s3_key= "Climate_Data/CountryContinent"
)
stage_population_density_to_redshift = StageToRedshiftOperator(
    task_id='Stage_population_density',
    dag=dag,    
    table="stagingPopulationDensity",
    s3_key="Climate_Data/PopulationDensity"
)

stage_ghg_emissions_to_redshift = StageToRedshiftOperator(
    task_id='Stage_total_ghg_emissions',
    dag=dag,    
    table="stagingGHGEmissions",
    s3_key="Climate_Data/TotalGHGEmissions/"
)
load_land_temperature_table = LoadFactOperator(
    task_id='Load_LandTemperature_fact_table',
    dag= dag,
    table="landtemperature",
    sql= SqlQueries.LandTemperature_table_insert,
    operation = "truncate"
)

load_climatic_factors_table = LoadFactOperator(
    task_id='Load_ClimateFactors_fact_table',
    dag= dag,
    table="climatefactors",
    sql= SqlQueries.ClimaticFactor_table_insert,
    operation = "truncate"
)

load_country_dimension_table = LoadDimensionOperator(
    task_id='Load_country_dim_table',
    dag=dag,
    table="country",
    sql=SqlQueries.country_table_insert,
    columns="""countryname, countrycode, continent"""
)

load_city_dimension_table = LoadDimensionOperator(
    task_id='Load_city_dim_table',
    dag=dag,
    table="city",
    sql=SqlQueries.city_table_insert,
    columns="""city, country, latitude, longitude"""
)

load_time_dimension_table = LoadDimensionOperator(
    task_id='Load_tim_dim_table',
    dag=dag,
    table="time",
    sql=SqlQueries.time_table_insert,
    columns="""dt, day, month, year"""
)


run_data_quality_checks = DataQualityOperator(
    task_id='Run_data_quality_checks',    
    dag=dag,
    checks = [
         {"table":"climatefactors", "check_sql": """SELECT COUNT(Distinct Year) FROM {}""" , "expected_result":24},
        {"table": "climatefactors", "check_sql":"""SELECT AverageYearlyTemperature from {} where  country ='Afghanistan' and year=2002""", "expected_result":15.537666666666668},
        {"table":"time", "check_sql": """SELECT COUNT(Distinct Year) FROM {}""" , "expected_result":24},
        {"table": "all", "check_sql": """SELECT COUNT(*) FROM {}""" , "expected_result":1}
    ]
)

end_operator = DummyOperator(task_id='Stop_execution',  dag=dag)

# Task dependencies 
start_operator >> stage_global_temp_by_city_to_redshift
start_operator >> stage_global_temp_by_country_to_redshift
start_operator >>  stage_country_to_redshift
start_operator >>  stage_population_density_to_redshift
start_operator >>  stage_ghg_emissions_to_redshift
stage_country_to_redshift >> load_land_temperature_table
stage_global_temp_by_city_to_redshift >> load_land_temperature_table 
stage_population_density_to_redshift >> load_climatic_factors_table
stage_global_temp_by_country_to_redshift >> load_climatic_factors_table
stage_ghg_emissions_to_redshift >> load_climatic_factors_table
load_land_temperature_table >> load_country_dimension_table 
load_climatic_factors_table >> load_country_dimension_table 
load_land_temperature_table >> load_city_dimension_table 
load_climatic_factors_table >> load_city_dimension_table 
load_land_temperature_table >> load_time_dimension_table 
load_climatic_factors_table >> load_time_dimension_table 
load_land_temperature_table >> run_data_quality_checks
load_climatic_factors_table >> run_data_quality_checks
load_country_dimension_table >> run_data_quality_checks
load_city_dimension_table >> run_data_quality_checks
load_time_dimension_table >> run_data_quality_checks
run_data_quality_checks >> end_operator

