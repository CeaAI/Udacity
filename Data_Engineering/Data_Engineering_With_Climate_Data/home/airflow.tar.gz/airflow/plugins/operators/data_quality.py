from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="redshift",
                 checks = [],
                 
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.conn_id = redshift_conn_id
        self.checks = checks
        
    def execute(self, context):
        task_instance = context['task_instance']
        table = task_instance.xcom_pull(key='table_name')
        redshift = PostgresHook(postgres_conn_id=self.conn_id)
        for check in self.checks:
            self.log.info(F"here is the table {check['table']}")
            if check["table"] == table:
                records = redshift.get_records(check["check_sql"].format(table))
                if records[0][0] < 1:
                    raise ValueError(f"Data quality check failed. {table} contained 0 rows")
                if records[0][0] != check["expected_result"]:
                    raise ValueError(f"Data quality check failed. {table} returned {records[0][0]} results instead of {check['expected_result']}")
                self.log.info(f"Data quality on table {table} check passed with {records[0][0]}")
            if check["table"] == "all":
                records =  redshift.get_records(check["check_sql"].format(table))
                if len(records) < 1 or len(records[0]) <  1:
                    raise ValueError(f"Data quality check failed. {table} returned no results")
            self.log.info(f"All Data quality check on table {table} passed")


                        
   