class SqlQueries:
    LandTemperature_table_insert = ("""
        Insert into landtemperatures(
        cityname,
        countryname,
        date,
        averagemonthlytemperature
        )
        SELECT
                stagingTempCity.city,
                stagingCountries.country_name as countryName, 
                cast(stagingTempCity.dt as date) as date,
                stagingTempCity.averageTemperature as averageMonthlyTemperature
                From stagingTempCity
                INNER JOIN stagingCountries ON stagingCountries.country_name = stagingTempCity.country 
    """)

    ClimaticFactor_table_insert = ("""
    Insert into climatefactors(
        totalemissions,
        populationdensity,
        "year",
        "countryname",
        averageyearlytemperature
        )
       SELECT 
            stagingGHGEmissions.totalGHGEmissions as totalEmissions
            ,stagingPopulationDensity.populationDensity
            ,stagingPopulationDensity.year 
            ,stagingPopulationDensity.country as countryname
			,avg(stagingTempCountry.averageTemperature) as averageYearlyTemperature
        From stagingGHGEmissions
        join stagingPopulationDensity on stagingGHGEmissions.country = stagingPopulationDensity.country
        join stagingTempCountry on  stagingGHGEmissions.country = stagingTempCountry.country
		Where stagingGHGEmissions.Year = extract(year from stagingTempCountry.dt)
        And stagingPopulationDensity.Year = stagingGHGEmissions.Year
		group by stagingPopulationDensity.year, stagingghgemissions.totalghgemissions,stagingpopulationdensity.populationdensity,               stagingpopulationdensity.country
        order by stagingPopulationDensity.year, countryname
    """)

    city_table_insert = ("""
        SELECT distinct city, country, latitude, longitude
        FROM stagingtempcity 
    """)

    country_table_insert = ("""
        SELECT distinct country_name, three_letter_country_code, continent_name
        FROM stagingcountries
    """)

    time_table_insert = ("""
        SELECT  cast(dt as date), extract(day from dt),extract(month from dt), extract(year from dt)
        FROM stagingtempcity
    """)